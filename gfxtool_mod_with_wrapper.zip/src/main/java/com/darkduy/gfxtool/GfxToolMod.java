package com.darkduy.gfxtool;

public class GfxToolMod {
    public static final String MODID = "gfxtool";
    public GfxToolMod() {
        System.out.println("[GFXTool] Main mod loaded.");
    }
}
